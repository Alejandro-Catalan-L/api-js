// Módulo principal
import {suma} from './suma.js'
import {resta} from './resta.js'
import {area} from './circulo.js'

let resultado1 = suma(2, 4)
console.log(resultado1)

let resultado2 = resta(2, 4)
console.log(resultado2)

let resultado3 = area(100)
console.log(resultado3)