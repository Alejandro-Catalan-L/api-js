//Módulo con cálculos particulares

const suma = (a, b) =>   a + b

export {suma}