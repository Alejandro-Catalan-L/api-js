//Módulo con cálculos particulares
const resta = (a, b) =>   a - b

export {resta}