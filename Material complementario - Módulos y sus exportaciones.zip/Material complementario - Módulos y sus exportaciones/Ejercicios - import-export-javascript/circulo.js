//Módulo con cálculos particulares
const PI = 3.14

export const area = (radio) => PI*radio**2
    